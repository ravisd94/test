﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.UI.HtmlControls;
namespace Zoel
{
    public partial class ValidTriangle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_Submit_Click(object sender, EventArgs e)
        {
        double A, B, C;
        lbl_Msg.ForeColor = Color.Red;
        if (txt_A.Text == "" || txt_B.Text == "" || txt_C.Text == "")
        {
            Response.Write("<script>alert('Please enter all the angles')</script>");            
            lbl_Msg.Text = "Error: Please enter all the angles";
        }
        else
        {
            if (double.TryParse(txt_A.Text, out A) && double.TryParse(txt_B.Text, out B) && double.TryParse(txt_C.Text, out C))
            {
                if (A < (B + C) && B < (A + C) && C < (A + B))
                {
                    lbl_Msg.ForeColor = Color.Green;
                    lbl_Msg.Text = "Valid Lengths for Triangle you can form the triangle with given angles";
                }
                else
                {
                    Response.Write("<script>alert('Not Valid Lengths to form a Triangle')</script>");                    
                    lbl_Msg.Text = "Error: Not Valid Lengths to form a Triangle please check the length";
                }
            }
            else
            {
                Response.Write("<script>alert('Please enter all the angles in Numbers only')</script>");
                lbl_Msg.Text = "Error: Please enter all the angles in Numbers only";

            }
        }

    }

        protected void btn_Clear_Click(object sender, EventArgs e)
        {
            lbl_Msg.Text = string.Empty;
                foreach (Control ctr in this.FindControl("form1").Controls)
                {
                    if (ctr is TextBox)
                    {
                        ((TextBox)ctr).Text = string.Empty;
                    }
                }
        }
    }
}