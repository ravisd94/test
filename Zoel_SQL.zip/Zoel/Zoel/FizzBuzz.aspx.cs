﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Zoel
{
    public partial class FizzBuzz : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                string result= (i % 3 == 0 && i % 5 == 0) ? "FizzBuzz" : ((i % 3 == 0) ? "Fizz" : ((i % 5 == 0) ? "Buzz" : i.ToString()));
                //For Detail description uncomment below code
                //Response.Write(i+" resulted output: "+result + "<br />");
                Response.Write(result + "<br />");
            }

        }
    }
}